mui.init({
	swipeBack: false,
	gestureConfig: {
		hold: true,
	},
	keyEventBind: {
		//		backbutton: true //关闭back按键监听
	},
	//	pullRefresh: {
	//		container: '#offCanvasWrapper',
	//		down: {
	//			callback: pulldownRefresh
	//		},
	//		//		up: {
	//		//			contentrefresh: '正在加载...',
	//		//			callback: pullupRefresh
	//		//		}
	//	}
	//	pullRefresh: {
	//		container: '#bodyId',
	//		down: {
	//			callback: pulldownRefresh
	//		}
	//	}
});

mui.plusReady(function() {
	
})